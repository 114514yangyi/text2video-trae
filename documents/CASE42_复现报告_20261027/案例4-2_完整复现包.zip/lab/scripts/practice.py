#!/usr/bin/env python3
"""Create a fresh manual-practice database, retaining every previous exercise."""
import argparse
import datetime as dt
import json
import os
import subprocess
import time
import urllib.request
from lab import LAB, RT, SOURCE, alive, php_command, port_free, start

def practice(action):
    pidfile=RT/'practice.pid'
    if action=='stop':
        if alive('practice'):
            os.kill(int(pidfile.read_text()),15)
            for _ in range(50):
                if not alive('practice'):
                    break
                time.sleep(.1)
        print('Practice service stopped; all databases and logs retained.')
        return
    if alive('practice'):
        print('Current practice is running. Stop it first with: python scripts/practice.py stop')
        return
    start()
    from reproduce import new_database
    name='dvwa_case42_manual_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    new_database(name)
    port_free(18044)
    logfile=RT/(name+'.log')
    with logfile.open('w') as log:
        proc=subprocess.Popen(php_command(18044),env=dict(os.environ,DVWA_CASE42_DATABASE=name),
                              stdout=log,stderr=log,start_new_session=True)
    pidfile.write_text(str(proc.pid))
    for _ in range(50):
        try:
            urllib.request.urlopen('http://127.0.0.1:18044/login.php',timeout=1).read()
            break
        except OSError:
            time.sleep(.1)
    info={'url':'http://127.0.0.1:18044','database':name,'pid':proc.pid}
    (RT/'practice.json').write_text(json.dumps(info,indent=2))
    print(json.dumps(info,ensure_ascii=False))
    print('Login: admin / password. Select the desired level in DVWA Security.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['start','stop'])
    practice(parser.parse_args().action)
