#!/usr/bin/env python3
"""Real-browser case 4-2 verification, restricted to this lab's loopback ports."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import urlencode

from lab import LAB, RT, BASE, SOURCE, php_command, port_free, sql
os.environ['PLAYWRIGHT_BROWSERS_PATH'] = str(RT / 'browsers')
from playwright.sync_api import sync_playwright

SCRIPT = '<script>alert("hello")</script>'
MIXED = '<Script>alert("hello")</Script>'
NESTED = '<sc<script>ript>alert("hello")</script>'
IMAGE = '<img src=1 onerror=alert("hello")>'
COOKIE = '<script>alert(document.cookie)</script>'
REFLECTED = [
 ('R01','low','普通输入','hello',False),
 ('R02','low','基本script',SCRIPT,True),
 ('R03','low','本机Cookie显示',COOKIE,True),
 ('R04','medium','小写script对照',SCRIPT,False),
 ('R05','medium','大小写绕过',MIXED,True),
 ('R06','medium','双写绕过',NESTED,True),
 ('R07','high','小写script对照',SCRIPT,False),
 ('R08','high','大小写对照',MIXED,False),
 ('R09','high','双写对照',NESTED,False),
 ('R10','high','img事件绕过',IMAGE,True),
 ('R11','impossible','script编码',SCRIPT,False),
 ('R12','impossible','img编码',IMAGE,False),
 ('R13','impossible','HTML实体输入','&lt;script&gt;alert("hello")&lt;/script&gt;',False),
 ('R14','impossible','额外一层URL编码','%3Cscript%3Ealert(%22hello%22)%3C%2Fscript%3E',False),
 ('R15','impossible','缺失CSRF令牌',SCRIPT,False),
 ('R16','impossible','错误CSRF令牌',SCRIPT,False),
]
STORED = [
 ('S01','low','Message基本script','message',SCRIPT,True),
 ('S02','low','Name长度限制绕过','name',SCRIPT,True),
 ('S03','low','Message本机Cookie','message',COOKIE,True),
 ('S04','medium','Message过滤对照','message',SCRIPT,False),
 ('S05','medium','Name小写对照','name',SCRIPT,False),
 ('S06','medium','Name大小写绕过','name',MIXED,True),
 ('S07','medium','Name双写绕过','name',NESTED,True),
 ('S08','high','Message事件过滤对照','message',IMAGE,False),
 ('S09','high','Name小写对照','name',SCRIPT,False),
 ('S10','high','Name大小写对照','name',MIXED,False),
 ('S11','high','Name双写对照','name',NESTED,False),
 ('S12','high','Name事件绕过','name',IMAGE,True),
 ('S13','impossible','Message编码','message',SCRIPT,False),
 ('S14','impossible','Name大小写编码','name',MIXED,False),
 ('S15','impossible','Name事件编码','name',IMAGE,False),
 ('S16','impossible','Name实体输入','name','&lt;img src=1 onerror=alert(1)&gt;',False),
 ('S17','impossible','缺失CSRF令牌','name',SCRIPT,False),
 ('S18','impossible','错误CSRF令牌','name',SCRIPT,False),
]

def save_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2))

def listen(page, messages):
    def dialog(d):
        messages.append({'type':d.type, 'message':d.message, 'time':dt.datetime.now(dt.timezone.utc).isoformat()})
        d.accept()
    page.on('dialog', dialog)

def login(browser, level, base):
    context = browser.new_context(viewport={'width':1280,'height':1000}, locale='en-US')
    context.add_cookies([{'name':'security','value':level,'url':base,'httpOnly':level=='impossible'}])
    # Never navigate to or contact a remote target during verification.
    blocked = []
    def route(r):
        url = r.request.url
        if url.startswith((base+'/', 'data:', 'about:')):
            r.continue_()
        else:
            blocked.append(url)
            r.abort()
    context.route('**/*', route)
    page = context.new_page()
    page.goto(base+'/login.php')
    page.locator('[name=username]').fill('admin')
    page.locator('[name=password]').fill('password')
    page.locator('[name=Login]').click()
    page.wait_for_url(base+'/index.php')
    return context, page, blocked

def capture(response, folder, stem):
    request = response.request
    payload = {'method':request.method,'url':request.url,'headers':request.all_headers(),
               'post_data':request.post_data,'status':response.status,'response_headers':response.all_headers()}
    save_json(folder/f'{stem}.http.json',payload)
    text = response.text()
    (folder/f'{stem}.response.html').write_text(text)
    return text

def snapshot(page, folder, stem):
    page.wait_for_timeout(450)
    page.screenshot(path=str(folder/f'{stem}.png'),full_page=True)
    (folder/f'{stem}.dom.html').write_text(page.content())

def reflected(browser, case, run):
    ident, level, label, payload, expected = case
    folder = run/ident
    folder.mkdir()
    context, page, blocked = login(browser,level,BASE)
    messages = []
    listen(page,messages)
    entry = BASE+'/vulnerabilities/xss_r/'
    page.goto(entry)
    token = page.locator('[name=user_token]').input_value() if level=='impossible' else None
    if ident in ('R15','R16'):
        data = {'name':payload}
        if ident=='R16':
            data['user_token']='wrong-token'
        response = context.request.get(entry,params=data,max_redirects=0)
        save_json(folder/'rejected.http.json',{'method':'GET','url':response.url,'status':response.status,
                                              'headers':response.headers,'body':response.text()})
        page.goto(entry)
        snapshot(page,folder,'page')
        result = {'id':ident,'type':'reflected','level':level,'label':label,'payload':payload,
                  'expected_alert':False,'dialogs':messages,'status':response.status,
                  'passed':response.status==302,'csrf_rejected':response.status==302}
    else:
        page.locator('[name=name]').fill(payload)
        with page.expect_response(lambda r:r.request.is_navigation_request() and '/xss_r/' in r.url) as event:
            page.locator('[type=submit]').click()
        response = event.value
        raw = capture(response,folder,'submission')
        snapshot(page,folder,'page')
        actual = len(messages)>0
        result = {'id':ident,'type':'reflected','level':level,'label':label,'payload':payload,
                  'expected_alert':expected,'dialogs':messages,'status':response.status,
                  'passed':actual==expected,'pre_text':page.locator('.vulnerable_code_area pre').all_text_contents(),
                  'url':page.url,'valid_token_used':token is not None,
                  'response_pre':raw[raw.find('<pre>Hello'):raw.find('</pre>',raw.find('<pre>Hello'))+6]}
        if ident=='R03':
            result['cookie_names_observed'] = [c['name'] for c in context.cookies() if c['name'] in ('PHPSESSID','security')]
            result['passed'] = result['passed'] and 'PHPSESSID=' in messages[0]['message']
    result['blocked_external_requests']=blocked
    save_json(folder/'result.json',result)
    context.close()
    return result

def new_database(name):
    # Every test gets a NEW database; no table or historical row is deleted.
    if not name.startswith('dvwa_case42_') or not name.replace('_','').isalnum():
        raise ValueError('Unexpected database name')
    sql(f'CREATE DATABASE `{name}`; CREATE TABLE `{name}`.users LIKE dvwa_case42.users; '
        f'INSERT INTO `{name}`.users SELECT * FROM dvwa_case42.users; '
        f'CREATE TABLE `{name}`.guestbook LIKE dvwa_case42.guestbook;')

def stored(browser,case,run,run_key):
    ident,level,label,field,payload,expected = case
    folder = run/ident
    folder.mkdir()
    database=f'dvwa_case42_{run_key}_{ident.lower()}'
    new_database(database)
    port_free(18043)
    env = dict(os.environ, DVWA_CASE42_DATABASE=database)
    log = (folder/'php.log').open('w')
    server = subprocess.Popen(php_command(18043),env=env,stdout=log,stderr=log)
    base='http://127.0.0.1:18043'
    try:
        for _ in range(50):
            try:
                import urllib.request
                urllib.request.urlopen(base+'/login.php',timeout=1).read()
                break
            except OSError:
                time.sleep(.1)
        context,page,blocked=login(browser,level,base)
        messages=[]
        listen(page,messages)
        entry=base+'/vulnerabilities/xss_s/'
        page.goto(entry)
        control={}
        if field=='name':
            control['original_maxlength']=page.locator('[name=txtName]').get_attribute('maxlength')
            page.locator('[name=txtName]').fill(payload)
            control['value_before_removing_maxlength']=page.locator('[name=txtName]').input_value()
            page.locator('[name=txtName]').evaluate('(el)=>el.removeAttribute("maxlength")')
            page.locator('[name=txtName]').fill(payload)
            page.locator('[name=mtxMessage]').fill('case42 '+ident)
        else:
            page.locator('[name=txtName]').fill(ident)
            page.locator('[name=mtxMessage]').fill(payload)
        if ident in ('S17','S18'):
            token=page.locator('[name=user_token]').input_value()
            data={'txtName':payload,'mtxMessage':'case42 '+ident,'btnSign':'Sign Guestbook'}
            if ident=='S18':
                data['user_token']='wrong-token'
            response=context.request.post(entry,form=data,max_redirects=0)
            save_json(folder/'rejected.http.json',{'method':'POST','url':response.url,'post_data':data,
                                                  'status':response.status,'headers':response.headers,'body':response.text()})
            raw=''
        else:
            with page.expect_response(lambda r:r.request.method=='POST' and '/xss_s/' in r.url) as event:
                page.locator('[name=btnSign]').click()
            response=event.value
            raw=capture(response,folder,'submission')
        snapshot(page,folder,'after-post')
        post_messages=list(messages)
        messages.clear()
        get_response=page.goto(entry)
        capture(get_response,folder,'reload')
        snapshot(page,folder,'after-get')
        reload_messages=list(messages)
        rows=sql(f'SELECT comment_id,HEX(name),HEX(comment) FROM `{database}`.guestbook;')
        (folder/'database.tsv').write_text(rows)
        count=int(sql(f'SELECT COUNT(*) FROM `{database}`.guestbook;').strip())
        fresh,fresh_page,fresh_blocked=login(browser,level,base)
        fresh_messages=[]
        listen(fresh_page,fresh_messages)
        fresh_page.goto(entry)
        snapshot(fresh_page,folder,'new-session')
        csrf=ident in ('S17','S18')
        passed=(response.status==302 and count==0 and not reload_messages and not fresh_messages) if csrf else (
                 response.status==200 and count==1 and bool(post_messages)==expected
                 and bool(reload_messages)==expected and bool(fresh_messages)==expected)
        result={'id':ident,'type':'stored','level':level,'label':label,'field':field,'payload':payload,
                'expected_alert':expected,'post_dialogs':post_messages,'get_dialogs':reload_messages,
                'new_session_dialogs':fresh_messages,'status':response.status,'database':database,
                'row_count':count,'maxlength_control':control,'passed':passed,
                'blocked_external_requests':blocked+fresh_blocked,'csrf_rejected':csrf and response.status==302}
        if not csrf:
            start=raw.find('<div id="guestbook_comments">')
            result['response_guestbook']=raw[start:start+800]
        # This official release ALSO encodes historical rows when displaying impossible.
        if ident=='S01':
            old,old_page,_=login(browser,'impossible',base)
            old_messages=[]
            listen(old_page,old_messages)
            old_response=old_page.goto(entry)
            capture(old_response,folder,'old-record-impossible')
            snapshot(old_page,folder,'old-record-impossible')
            result['old_record_at_impossible_dialogs']=old_messages
            result['old_record_at_impossible_html']=old_page.locator('#guestbook_comments').inner_html()
            result['passed']=passed and not old_messages and '&lt;script&gt;' in result['old_record_at_impossible_html']
            old.close()
        result['cookie_flags']=fresh.cookies()
        fresh.close()
        context.close()
        save_json(folder/'result.json',result)
        return result
    finally:
        server.terminate()
        server.wait(timeout=10)
        log.close()

def main():
    run_key=dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    run=LAB/'results'/run_key
    run.mkdir()
    results=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        version=browser.version
        for case in REFLECTED:
            result=reflected(browser,case,run)
            results.append(result)
            print(result['id'], 'PASS' if result['passed'] else 'FAIL', result['label'],flush=True)
        for case in STORED:
            result=stored(browser,case,run,run_key)
            results.append(result)
            print(result['id'], 'PASS' if result['passed'] else 'FAIL', result['label'],flush=True)
        diagnostics=[]
        # Controlled session reuse: only the session emitted by this local test.
        cookie_text=next(r for r in results if r['id']=='R03')['dialogs'][0]['message']
        cookies=dict(item.strip().split('=',1) for item in cookie_text.split(';') if '=' in item)
        replay=browser.new_context()
        replay_page=replay.new_page()
        replay_page.goto(BASE+'/index.php')
        anonymous_url=replay_page.url
        replay.add_cookies([{'name':name,'value':value,'url':BASE} for name,value in cookies.items()
                            if name in ('PHPSESSID','security')])
        replay_page.goto(BASE+'/index.php')
        replay_ok='/login.php' in anonymous_url and replay_page.url==BASE+'/index.php'
        replay_page.screenshot(path=str(run/'local-session-reuse.png'),full_page=True)
        diagnostics.append({'id':'C01','label':'仅复用本轮本机实验Cookie','anonymous_url':anonymous_url,
                            'authenticated_url':replay_page.url,'passed':replay_ok})
        replay.close()
        protected,protected_page,_=login(browser,'impossible',BASE)
        visible=protected_page.evaluate('document.cookie')
        session=next(c for c in protected.cookies() if c['name']=='PHPSESSID')
        diagnostics.append({'id':'C02','label':'impossible全新会话HttpOnly核验','document_cookie':visible,
                            'session_httponly':session['httpOnly'],
                            'passed':session['httpOnly'] and 'PHPSESSID=' not in visible})
        protected.close()
        save_json(run/'diagnostics.json',diagnostics)
        browser.close()
    hashes={str(f.relative_to(LAB)):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in list((SOURCE/'vulnerabilities/xss_r/source').glob('*.php'))+
                     list((SOURCE/'vulnerabilities/xss_s/source').glob('*.php'))+
                     [LAB/'downloads/DVWA-2.3.tar.gz',SOURCE/'dvwa/includes/dvwaPage.inc.php']}
    summary={'created':dt.datetime.now(dt.timezone.utc).isoformat(),'chromium':version,
             'passed':sum(r['passed'] for r in results),'total':len(results),'results':results,
             'diagnostics':diagnostics,'sha256':hashes}
    save_json(run/'summary.json',summary)
    (LAB/'results/LATEST').write_text(run_key+'\n')
    print(json.dumps({'run':str(run),'passed':summary['passed'],'total':summary['total']}))
    return 0 if summary['passed']==summary['total'] and all(d['passed'] for d in diagnostics) else 1

if __name__=='__main__':
    sys.exit(main())
