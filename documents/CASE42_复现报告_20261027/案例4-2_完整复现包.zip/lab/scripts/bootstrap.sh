#!/usr/bin/env bash
set -euo pipefail
LAB_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$LAB_DIR"
for dependency in php mysqld mysql dpkg-deb python3; do
    command -v "$dependency" >/dev/null || { echo "Missing prerequisite: $dependency"; exit 1; }
done
mkdir -p downloads runtime results
if [[ ! -d DVWA ]]; then
    python3 - <<'PY'
import tarfile
from pathlib import Path
with tarfile.open('downloads/DVWA-2.3.tar.gz') as archive:
    archive.extractall('.', filter='data')
Path('DVWA-2.3').rename('DVWA')
PY
fi
if [[ ! -f runtime/php-mysql/usr/lib/php/20190902/mysqli.so ]]; then
    dpkg-deb -x downloads/php7.4-mysql_7.4.3-4ubuntu2.29_amd64.deb runtime/php-mysql
fi
if [[ ! -x runtime/venv/bin/python ]]; then
    python3 -m venv runtime/venv
    runtime/venv/bin/pip install -r requirements.lock.txt
fi
export PLAYWRIGHT_BROWSERS_PATH="$LAB_DIR/runtime/browsers"
runtime/venv/bin/python -m playwright install chromium --only-shell
runtime/venv/bin/python scripts/lab.py start
