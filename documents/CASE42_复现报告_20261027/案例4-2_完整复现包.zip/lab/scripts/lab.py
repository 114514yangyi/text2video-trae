#!/usr/bin/env python3
"""Manage only this user's loopback DVWA teaching lab; never reset data."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import time
import urllib.parse
import urllib.request
import http.cookiejar

LAB = Path(__file__).resolve().parents[1]
RT = LAB / 'runtime'
SOURCE = LAB / 'DVWA'
BASE = 'http://127.0.0.1:18042'
MYSQLD = shutil.which('mysqld') or '/home/wxy/anaconda3/bin/mysqld'
MYSQL = str(Path(MYSQLD).with_name('mysql'))

def sql(query):
    return subprocess.run([MYSQL, f'--defaults-file={RT / "client.cnf"}', '-N', '-B'],
                          input=query, text=True, check=True, capture_output=True).stdout

def alive(name):
    f = RT / f'{name}.pid'
    if not f.exists():
        return False
    try:
        pid = int(f.read_text())
        cmd = Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\x00', b' ')
        return str(LAB).encode() in cmd
    except (ValueError, OSError):
        return False

def port_free(port):
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', port))

def php_command(port=18042):
    ext = RT / 'php-mysql/usr/lib/php/20190902'
    return ['php', '-d', f'extension={ext}/mysqlnd.so', '-d', f'extension={ext}/mysqli.so',
            '-d', f'extension={ext}/pdo_mysql.so', '-d', f'session.save_path={RT}/sessions',
            '-d', 'display_errors=0', '-d', 'log_errors=1',
            '-S', f'127.0.0.1:{port}', '-t', str(SOURCE)]

def start():
    RT.mkdir(exist_ok=True)
    (RT / 'sessions').mkdir(exist_ok=True, mode=0o700)
    data = RT / 'mysql-data-v1'
    conf = RT / 'mysql.cnf'
    conf.write_text(f'''[mysqld]
basedir={Path(MYSQLD).resolve().parents[1]}
lc-messages-dir={Path(MYSQLD).resolve().parents[1]}/share/mysql
datadir={data}
socket={RT}/mysql.sock
pid-file={RT}/mysql.pid
bind-address=127.0.0.1
port=13342
log-error={RT}/mysql.log
max-connections=20
innodb-buffer-pool-size=32M
innodb-log-file-size=16M
performance-schema=OFF
skip-name-resolve
''')
    fresh = not data.exists()
    if not alive('mysql'):
        port_free(13342)
        if fresh:
            data.mkdir(mode=0o700)
            subprocess.run([MYSQLD, f'--defaults-file={conf}', '--initialize-insecure'], check=True)
        with (RT / 'mysql-launch.log').open('a') as log:
            process = subprocess.Popen([MYSQLD, f'--defaults-file={conf}'], stdout=log, stderr=log,
                                       start_new_session=True)
        for _ in range(100):
            if (RT / 'mysql.sock').exists() and alive('mysql'):
                break
            if process.poll() is not None:
                raise RuntimeError('MySQL failed: see runtime/mysql.log')
            time.sleep(.2)
        else:
            raise RuntimeError('MySQL startup timeout')
        if fresh:
            subprocess.run([MYSQL, '--no-defaults', f'--socket={RT}/mysql.sock', '-u', 'root'],
                           input="ALTER USER 'root'@'localhost' IDENTIFIED BY 'case42-root-local';\n"
                                 "CREATE USER 'dvwa'@'127.0.0.1' IDENTIFIED BY 'case42-local-only';\n"
                                 "GRANT ALL PRIVILEGES ON `dvwa_case42%`.* TO 'dvwa'@'127.0.0.1';\n",
                           text=True, check=True)
    client = RT / 'client.cnf'
    client.write_text(f'[client]\nuser=root\npassword=case42-root-local\nsocket={RT}/mysql.sock\n')
    client.chmod(0o600)
    config = (SOURCE / 'config/config.inc.php.dist').read_text()
    config = config.replace("= 'dvwa';", "= getenv('DVWA_CASE42_DATABASE') ?: 'dvwa_case42';", 1)
    config = config.replace("= 'p@ssw0rd';", "= 'case42-local-only';")
    config = config.replace("= '3306';", "= '13342';")
    (SOURCE / 'config/config.inc.php').write_text(config)
    if not alive('php'):
        port_free(18042)
        with (RT / 'php.log').open('a') as log:
            p = subprocess.Popen(php_command(), stdout=log, stderr=log, start_new_session=True)
        (RT / 'php.pid').write_text(str(p.pid))
        for _ in range(50):
            try:
                urllib.request.urlopen(BASE + '/setup.php', timeout=2).read()
                break
            except OSError:
                time.sleep(.2)
        else:
            raise RuntimeError('PHP startup timeout')
    exists = sql("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='dvwa_case42' AND table_name='users';").strip()
    if exists == '0':
        # The official reset handler is invoked only when no lab users table exists.
        if sql("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='dvwa_case42';").strip() != '0':
            raise RuntimeError('Partial lab schema found; refusing to reset existing tables')
        jar = http.cookiejar.CookieJar()
        client_http = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        page = client_http.open(BASE + '/setup.php').read().decode()
        token = re.search(r"name='user_token' value='([^']+)'", page).group(1)
        body = urllib.parse.urlencode({'create_db': 'Create / Reset Database', 'user_token': token}).encode()
        client_http.open(BASE + '/setup.php', body).read()
        assert sql('SELECT COUNT(*) FROM dvwa_case42.users;').strip() == '5'
        (RT / 'initialized.json').write_text(json.dumps({'created':time.time(),'database':'dvwa_case42'}))
    status()

def stop():
    for name in ('php', 'mysql'):
        if alive(name):
            pid = int((RT / f'{name}.pid').read_text())
            os.kill(pid, signal.SIGTERM)
            print(f'Stopping lab {name}, PID {pid}; data retained')
            for _ in range(100):
                if not alive(name):
                    break
                time.sleep(.1)

def status():
    print(json.dumps({'url': BASE, 'php': alive('php'), 'mysql': alive('mysql'),
                      'database_port':13342,'data_retained':str(RT / 'mysql-data-v1')}, ensure_ascii=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['start','stop','status'])
    args = parser.parse_args()
    {'start':start,'stop':stop,'status':status}[args.action]()
