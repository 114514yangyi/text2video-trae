# 案例 4-2 复现包

本包对应 2026-10-27 实测：反射型 16 项、存储型 18 项均符合各自预期，另外 2 项本机 Cookie 核验通过。PASS 包含“被拦截”的成功对照，不表示 34 项全部注入成功。

## 当前服务器最快使用

```bash
cd /home/wxy/text2video/.trae/reference/dvwa-case42-20261027
runtime/venv/bin/python scripts/lab.py start
runtime/venv/bin/python scripts/reproduce.py
```

登录：`http://127.0.0.1:18042`，账号 `admin`，密码 `password`。远程电脑先在本地终端建立转发：

```bash
ssh -N -L 18042:127.0.0.1:18042 -L 18044:127.0.0.1:18044 用户名@服务器地址
```

在电脑浏览器访问同一回环地址。主站只监听服务器本机，不公开到互联网。

## 包内目录

- `report/`：PDF、Word、独立 HTML、Markdown 和九张代表截图。
- `lab/`：操作脚本、依赖锁定文件、官方源码包和 Ubuntu PHP 数据库扩展包。
- `lab/results/`：本轮原始请求、响应、DOM、截图、对话框事件、数据库字段十六进制值。
- `evidence/databases.sql`：仅此独立实验的主库和最终一轮 18 个测试库的逻辑备份，不含服务器其他数据库。
- `evidence/verification.log`：最终完整运行输出。
- `materials/`：用户提供的七张案例截图。
- `MANIFEST.sha256`：包内文件校验值。

## 同一服务器换目录重建

先停止旧主站和练习站，避免固定端口冲突。然后进入解压后的 `lab/`：

```bash
bash scripts/bootstrap.sh
runtime/venv/bin/python scripts/reproduce.py
runtime/venv/bin/python scripts/build_report.py
```

依赖：服务器现有 PHP7.4、MySQL5.7 二进制、Python3.12、dpkg-deb；Python 包和 Chromium 首次重建需联网。包内未打入 Python 虚拟环境、浏览器或 MySQL 程序。跨系统需自行匹配 PHP 扩展，不能直接复用本 Ubuntu20.04 的 .so 文件。

## 创建干净的手动练习库

```bash
runtime/venv/bin/python scripts/practice.py stop
runtime/venv/bin/python scripts/practice.py start
```

访问 `http://127.0.0.1:18044`，重新登录，选择安全级别。每次 start 创建新数据库；停止服务不会删旧记录。

## 停止服务

```bash
runtime/venv/bin/python scripts/practice.py stop
runtime/venv/bin/python scripts/lab.py stop
```

所有数据均保留。`databases.sql` 是可选备份，不需要导入才能正常重跑；不要导入服务器已有的其他业务数据库。

报告中的页面截图摄于关闭原生弹框之后；实际弹框类型、内容、时间见相应 JSON。使用官方 DVWA2.3，未改 XSS 处理代码。该版本 impossible 在公共输出函数中还会编码旧留言，报告已据实说明。
